import requests
from rest_framework.decorators import api_view
from rest_framework.response import Response
from .models import SearchResult
from .serializers import SearchResultSerializer
from urllib.parse import quote

# Create your views here.
GOOGLE_API_KEY = "AIzaSyBqL4nnGUuPVMJW7948w0RemjyoeJQFP0I"
SEARCH_ENGINE_ID = "27f8a6a4adf664994"
YOUTUBE_API_KEY = "AIzaSyBqL4nnGUuPVMJW7948w0RemjyoeJQFP0I"

def search_google(query):
    url = f"https://www.googleapis.com/customsearch/v1?q={query}&key={GOOGLE_API_KEY}&cx={SEARCH_ENGINE_ID}"
    response = requests.get(url).json()
    results = []
    if "items" in response:
        for item in response["items"]:
            link = item.get("link")
            if link:
                results.append({
                    "source" : "Google",
                    "title" : item.get("title"),
                    "link" : link,
                    "snippet" : item.get("snippet", ""),
                })
    return results

def search_youtube(query):
    url = f"https://www.googleapis.com/youtube/v3/search?part=snippet&q={query}&key={YOUTUBE_API_KEY}"
    response = requests.get(url).json()
    results = []
    if "items" in response:
        for item in response["items"]:
            video_id = item["id"].get("videoId")
            if video_id:
                video_link = f"https://www.youtube.com/watch?v={video_id}"
                results.append({
                    "source" : "YouTube",
                    "title" : item["snippet"]["title"],
                    "link" : video_link,
                    "snippet" : item["snippet"]["description"],
                })
    return results

def search_linkedin(query):
    search_url = f"https://www.linkedin.com/search/results/all/?keywords={quote(query)}"
    return [{
        "source" : "LinkedIn",
        "title" : f"LinkedIn Results for {query}",
        "link" : search_url,
        "snippet" : "Click to view LinkedIn Search Results",
    }]

@api_view(["GET"])
def search_api(requests):
    query = requests.GET.get("q")
    if not query:
        return Response({"Error" : "Query parameter 'q' is required"}, status= 400)
    
    google_results = search_google(query)
    youtube_results = search_youtube(query)
    linkedin_results = search_linkedin(query)

    all_results = google_results + youtube_results + linkedin_results

    # saving results database
    for result in all_results:
        if result["link"]:
            SearchResult.objects.create(**result)

    # fetching results from database
    saved_results = SearchResult.objects.all().order_by("-created_at")[:10]
    serializer = SearchResultSerializer(saved_results, many= True)
    return Response(serializer.data)