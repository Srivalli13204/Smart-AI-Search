import React, { useState, useEffect } from "react";

const SearchResults = ({ results }) => {
    const [sortBy, setSortBy] = useState("relevance");
    const [filterBy, setFilterBy] = useState("all");
    const [filteredResults, setFilteredResults] = useState([]);

    useEffect(() => {
        console.log("Original Results :", results);
        console.log("Filter By :", filterBy)
        console.log("Sort By :", sortBy);

        let updatedResults = [...results];

        // applying filtering
        if (filterBy !== "all") {
            updatedResults = updatedResults.filter((result) => {
                return result.source.toLowerCase() === filterBy.toLowerCase();
            });
        }

        // applying sorting
        if (sortBy === "date") {
            updatedResults.sort((a, b) => {
                const dateA = new Date(a.date || "2000-01-01");
                const dateB = new Date(b.date || "2000-01-01");
                return dateB - dateA;
            });
        }

        setFilteredResults(updatedResults);
    }, [results, filterBy, sortBy]);

    return (
        <div className="results-container">
            <div className="filters">
                <label>Sort By : </label>
                <select onChange={(e) => setSortBy(e.target.value)} value={sortBy}>
                    <option value="relevance">Relevance</option>
                    <option value="date">Newest</option>
                </select>

                <label>Filter By : </label>
                <select onChange={(e) => setFilterBy(e.target.value)} value={filterBy}>
                    <option value="all">All</option>
                    <option value="google">Google</option>
                    <option value="youtube">YouTube</option>
                    <option value="linkedin">LinkedIn</option>
                </select>
            </div>

            <div className="results">
                {filteredResults.length === 0 ? (
                    <p className="no-results">No results found.</p>
                ) : (
                    filteredResults.map((result, index) => (
                        <div key={index} className="result-card">
                            <h3>{result.title}</h3>
                            <p>{result.snippet}</p>
                            <a href={result.link} target="_blank" rel="noopener noreferrer">View Source</a>
                            <p><strong>Source :</strong> {result.source}</p>
                        </div>
                    ))
                )}
            </div>
        </div>
    );
};

export default SearchResults;