import "./App.css";

import React, { useState} from "react";
import axios from "axios";
import SearchBar from "./components/SearchBar";
import SearchResults from "./components/SearchResults";

const App = () => {
  const [results, setResults] = useState([]);

  const handleSearch = async (query) => {
    try {
      const response = await axios.get(`http://127.0.0.1:8000/api/search/?q=${query}`);
      setResults(response.data);
    }
    catch(error) {
      console.error("Error fetching search results", error);
    }
  };

  return (
    <div className="app-container">
      <header className="header">
        <h1>Smart AI Search 🚀</h1>
        <p>Find the most relevant results from Google, YouTube, and LinkedIn.</p>
      </header>

      <main className="content">
        <SearchBar onSearch={handleSearch} />
        <SearchResults results={results} /> 
      </main>
      
      <footer className="footer">
        <p>© 2025 Powered by AI | Built with React & Django</p>

      </footer>
    </div>
  );
};

export default App;